<?php

define ("RACINE" ,__DIR__);

