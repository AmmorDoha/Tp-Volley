package ma.example.projetws;

import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.*;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

public class AddEtudiant extends AppCompatActivity implements View.OnClickListener {

    EditText nom, prenom;
    Spinner ville;
    CheckBox m;
    Button btnAjouter;
    RequestQueue requestQueue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_etudiant);

        nom = findViewById(R.id.editTextNom);
        prenom = findViewById(R.id.editTextPrenom);
        ville = findViewById(R.id.spinnerVille);
        m = findViewById(R.id.checkBoxHomme);
        btnAjouter = findViewById(R.id.buttonAjouter);

        btnAjouter.setOnClickListener(this);
        requestQueue = Volley.newRequestQueue(this);

        // Init spinner (optionnel si déjà fait dans le layout)
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.villes_array, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        ville.setAdapter(adapter);
    }
    @Override
    public void onClick(View v) {
        String url = "http://your-api-endpoint.com/ajouter"; // Remplace par ton URL réelle

        StringRequest request = new StringRequest(Request.Method.POST, url,
                response -> {
                    Toast.makeText(AddEtudiant.this, "Ajouté avec succès", Toast.LENGTH_SHORT).show();
                },
                error -> {
                    Toast.makeText(AddEtudiant.this, "Erreur : " + error.getMessage(), Toast.LENGTH_SHORT).show();
                }) {
            @Override
            protected Map<String, String> getParams() {
                String sexe = m.isChecked() ? "homme" : "femme";

                Map<String, String> params = new HashMap<>();
                params.put("nom", nom.getText().toString());
                params.put("prenom", prenom.getText().toString());
                params.put("ville", ville.getSelectedItem().toString());
                params.put("sexe", sexe);
                return params;
            }
        };

        requestQueue.add(request);
    }
}